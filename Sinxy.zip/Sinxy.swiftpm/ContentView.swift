import SwiftUI
import RealityKit
struct ContentView: View {
    var body: some View {
        ARViewContainer().edgesIgnoringSafeArea(.all)
    }
}
struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let anchorEntity = AnchorEntity(plane: .horizontal)
        let sphereRadius: Float = 0.01
        let gridSize = 30
        let spacing: Float = 1 / 5
        for siny in 0..<gridSize {
            for sinx in 0..<gridSize {
                let sphereMesh = MeshResource.generateSphere(radius: sphereRadius)
                let sphereMaterial = SimpleMaterial(color: .red, isMetallic: false)
                let sphereEntity = ModelEntity(mesh: sphereMesh, materials: [sphereMaterial])
                let x = Float(sinx) * spacing - (Float(gridSize) / 2) * spacing
                let y = Float(siny) * spacing - (Float(gridSize) / 2) * spacing
                let sinX = sin(x)
                let sinY = sin(y)
                let z = sinX * sinY
                let transform = Transform(translation: SIMD3<Float>(x, z, y) / 10)
                sphereEntity.transform = transform
                anchorEntity.addChild(sphereEntity)
                arView.scene.addAnchor(anchorEntity)
            }
        }
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {}
}

